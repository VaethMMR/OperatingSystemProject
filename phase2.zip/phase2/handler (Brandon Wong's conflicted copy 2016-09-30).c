#include <stdio.h>
#include <phase1.h>
#include <phase2.h>
#include "message.h"

int debugNullsys = 0;
int debugClock = 0;
int debugDisk = 0;
int debugTerm = 0;
int debugSyscall = 0;

int interruptCounter = 0;

/* an error method to handle invalid syscalls */
void nullsys(systemArgs *args)
{
    checkKernelMode("nullsys");
    USLOSS_Console("nullsys(): Invalid syscall %d. Halting...\n", args->number);
    USLOSS_Halt(1);
} /* nullsys */


/* method to handle clock interrupts */
void clockHandler2(int dev, void *arg)
{

   checkKernelMode("clockHandler2");
   if(DEBUG2 && debugClock)
     USLOSS_Console("clockHandler2(): called\n");
	
	// error check, is the device actually a clock device?
	if(dev != USLOSS_CLOCK_INT){
		USLOSS_Console("clockHandler(): dev is %d, which is not a clock device!", dev);
		USLOSS_Halt(1);
	}
	
	// conditionally send to clock I/O mailbox every 5th clock interrupt	
	
	// call readCurrStartTime, check since then (USLOSS_Clock), call time slice; every 5th interrupt send
	int startTime = readCurrStartTime();
	int currTime = USLOSS_Clock();
	int nowTime = currTime - startTime;
	if(nowTime >= 80000){
		timeSlice();
		interruptCounter++;
	}
	
	if(interruptCounter % 5 == 0){
		MboxCondSend(0,0,sizeof(int));
	}

} /* clockHandler */

/* method to handle disk interrupts */
void diskHandler(int dev, void *arg)
{

    checkKernelMode("diskHandler");
    if(DEBUG2 && debugDisk)
      USLOSS_Console("diskHandler(): called\n");

	// error check, is the device actually a disk device?
	if(dev != USLOSS_DISK_INT){
		USLOSS_Console("diskHandler(): dev is %d, which is not a disk device!", dev);
		USLOSS_Halt(1);
	}
	
	// is the unit number in the correct range?
	int unit_number = *((int *)arg);
	if(unit_number < 1 || unit_number > 2){
		USLOSS_Console("diskHandler(): the unit number is [%d], outside the range", unit_number);
		USLOSS_Halt(1);
	}
	
	// int USLOSS_DeviceInput(int dev, int unit, int *status);
	int device_input = USLOSS_DeviceInput(dev, unit_number, (int*) arg);
	
	// conditionally send contents of status register to appropriate mailbox
	mboxPtr diskMB = arg;
	MboxCondSend(unit_number, diskMB, sizeof(int));

} /* diskHandler */

/* method to handle term interrupts */
void termHandler(int dev, void *arg)
{

    checkKernelMode("termHandler");
    if(DEBUG2 && debugTerm)
      USLOSS_Console("termHandler(): called\n");

    // error check, is the device actually a term device?
	if(dev != USLOSS_TERM_INT){
		USLOSS_Console("termHandler(): dev is %d, which is not a term device!", dev);
		USLOSS_Halt(1);
	}
	
	// is the unit number in the correct range?
	int unit_number = *((int *)arg);
	if(unit_number < 3 || unit_number > 6){
		USLOSS_Console("termHandler(): the unit number is [%d], outside the range", unit_number);
		USLOSS_Halt(1);
	}
	
	// int USLOSS_DeviceInput(int dev, int unit, int *status);
	int device_input = USLOSS_DeviceInput(dev, unit_number, (int*) arg);
	
	// conditionally send contents of status register to appropriate mailbox
	mboxPtr termMB = arg;
	MboxCondSend(unit_number, termMB, device_input);
	
} /* termHandler */


// DO THIS ONE LAST
/* method to handle syscall */
void syscallHandler(int dev, void *arg)
{

    checkKernelMode("syscallHandler");
    if(DEBUG2 && debugSyscall)
      USLOSS_Console("syscallHandler(): called\n");

    // error check, is the device actually a syscall device?
	if(dev != USLOSS_SYSCALL_INT){
		USLOSS_Console("syscallHandler(): dev is %d, which is not a syscall device!", dev);
		USLOSS_Halt(1);
	}
	
	// set to syscall to nullsys
	int point = *((int *)arg);				// get the unit number to point in the syscall vector table
//	systemArgs *function = arg[point];		// get the syscall
//	nullsys(function);						// set syscall to nullsys

} /* syscallHandler */
