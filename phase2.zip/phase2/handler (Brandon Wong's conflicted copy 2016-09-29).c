#include <stdio.h>
#include <phase1.h>
#include <phase2.h>
#include "message.h"

int debugNullsys = 0;
int debugClock = 0;
int debugDisk = 0;
int debugTerm = 0;
int debugSyscall = 0;

int interruptCounter = 0;

/* an error method to handle invalid syscalls */
void nullsys(systemArgs *args)
{
    checkKernelMode("nullsys");
    USLOSS_Console("nullsys(): Invalid syscall. Halting...\n");
    USLOSS_Halt(1);
} /* nullsys */


void clockHandler2(int dev, void *arg)
{
    checkKernelMode("clockHandler2");
    if(DEBUG2 && debugClock)
      USLOSS_Console("clockHandler2(): called\n");
	
	// error check, is the device actually a clock device?
	if(dev != USLOSS_CLOCK_INT){
		USLOSS_Console("clockHandler(): dev is %d, which is not a clock device!", dev);
		USLOSS_Halt(1);
	}
	
	// conditionally send to clock I/O mailbox every 5th clock interrupt	
	
	// call readCurrStartTime, check since then (USLOSS_Clock), call time slice; every 5th interrupt send
	int startTime = readCurrStartTime();
	int currTime = USLOSS_Clock();
	int nowTime = currTime - startTime;
	if(nowTime >= 80000){
		timeSlice();
		interruptCounter++;
	}
	
	if(interruptCounter % 5 == 0){
		MboxCondSend(0,0,sizeof(int);
		//MboxCondSend();
	}
	
} /* clockHandler */


void diskHandler(int dev, void *arg)
{
    checkKernelMode("diskHandler");
    if(DEBUG2 && debugDisk)
      USLOSS_Console("diskHandler(): called\n");

	// error check, is the device actually a disk device?
	if(dev != USLOSS_DISK_INT){
		USLOSS_Console("diskHandler(): dev is %d, which is not a disk device!", dev);
		USLOSS_Halt(1);
	}
	
	// is the unit number in the correct range?
	
	// call timeSlice when necessary
	
	// conditionally send contents of status register to appropriate mailbox

} /* diskHandler */


void termHandler(int dev, void *arg)
{
    checkKernelMode("termHandler");
    if(DEBUG2 && debugTerm)
      USLOSS_Console("termHandler(): called\n");

  // error check, is the device actually a term device?
	if(dev != USLOSS_TERM_INT){
		USLOSS_Console("termHandler(): dev is %d, which is not a term device!", dev);
		USLOSS_Halt(1);
	}
	
	// is the unit number in the correct range?
	
	// conditionally send contents of status register to appropriate mailbox
	
} /* termHandler */


// DO THIS ONE LAST
void syscallHandler(int dev, void *arg)
{
    checkKernelMode("syscallHandler");
    if(DEBUG2 && debugSyscall)
      USLOSS_Console("syscallHandler(): called\n");

  // error check, is the device actually a syscall device?
	if(dev != USLOSS_SYSCALL_INT){
		USLOSS_Console("syscallHandler(): dev is %d, which is not a syscall device!", dev);
		USLOSS_Halt(1);
	}
} /* syscallHandler */
